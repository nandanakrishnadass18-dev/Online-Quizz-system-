// LOGIN
const loginForm = document.getElementById("loginForm");

if (loginForm) {
    loginForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const name = document.getElementById("playerName").value.trim();

        if (!name) {
            alert("Please enter your name!");
            return;
        }

        localStorage.setItem("playerName", name);
        window.location.href = "category.html";
    });
}


// CATEGORY SELECTION
function selectCategory(category) {
    localStorage.setItem("category", category);
    localStorage.setItem("score", "0");
    localStorage.setItem("questionIndex", "0");

    window.location.href = "quiz.html";
}


// QUIZ
let quizQuestions = [];
let currentQuestionIndex = 0;
let score = 0;
let selectedAnswer = false;

const questionText = document.getElementById("questionText");

if (questionText) {
    loadQuiz();
}


// LOAD QUESTIONS FROM BACKEND
async function loadQuiz() {
    const category = localStorage.getItem("category");

    document.getElementById("categoryTitle").textContent =
        (category || "Quiz") + " Quiz";

    try {
        const response = await fetch(
            "http://localhost:5000/api/questions"
        );

        if (!response.ok) {
            throw new Error("Could not retrieve questions from server.");
        }

        const allQuestions = await response.json();

        quizQuestions = allQuestions.filter(function (item) {
            return item.category &&
                category &&
                item.category.toLowerCase() === category.toLowerCase();
        });

        if (quizQuestions.length === 0) {
            questionText.textContent =
                "No questions found for this category.";

            document.getElementById("optionsContainer").innerHTML = "";

            document.getElementById("nextBtn").style.display = "none";

            return;
        }

        currentQuestionIndex = 0;
        score = 0;

        showQuestion();

    } catch (error) {
        console.error(error);

        questionText.textContent =
            "Unable to load questions. Please check your backend server.";
    }
}


// SHOW QUESTION
function showQuestion() {
    selectedAnswer = false;

    const question = quizQuestions[currentQuestionIndex];

    document.getElementById("questionCounter").textContent =
        "Question " +
        (currentQuestionIndex + 1) +
        " of " +
        quizQuestions.length;

    document.getElementById("progressBar").style.width =
        ((currentQuestionIndex + 1) / quizQuestions.length * 100) + "%";

    questionText.textContent = question.question;

    document.getElementById("feedbackMessage").textContent = "";

    const optionsContainer =
        document.getElementById("optionsContainer");

    optionsContainer.innerHTML = "";

    const nextButton = document.getElementById("nextBtn");

    nextButton.disabled = true;

    nextButton.textContent =
        currentQuestionIndex === quizQuestions.length - 1
            ? "See Results 🏆"
            : "Next Question →";


    question.options.forEach(function (option) {

        const button = document.createElement("button");

        button.className = "option-btn";

        button.textContent = option;

        button.type = "button";

        button.addEventListener("click", function () {
            checkAnswer(option, button);
        });

        optionsContainer.appendChild(button);
    });
}


// CHECK ANSWER
function checkAnswer(answer, clickedButton) {

    if (selectedAnswer) {
        return;
    }

    selectedAnswer = true;

    const question = quizQuestions[currentQuestionIndex];

    const correctAnswer = question.answer;

    const optionButtons =
        document.querySelectorAll(".option-btn");


    optionButtons.forEach(function (button) {

        button.disabled = true;

        if (button.textContent === String(correctAnswer)) {
            button.classList.add("correct");
        }
    });


    if (String(answer) === String(correctAnswer)) {

        score++;

        clickedButton.classList.add("correct");

        document.getElementById("feedbackMessage").textContent =
            "🎉 Correct answer! Great job!";

    } else {

        clickedButton.classList.add("wrong");

        document.getElementById("feedbackMessage").textContent =
            "💪 Not quite! The correct answer is " +
            correctAnswer;
    }


    document.getElementById("nextBtn").disabled = false;
}


// NEXT QUESTION
const nextBtn = document.getElementById("nextBtn");

if (nextBtn) {

    nextBtn.addEventListener("click", async function () {

        if (!selectedAnswer) {
            return;
        }

        currentQuestionIndex++;


        // MORE QUESTIONS
        if (currentQuestionIndex < quizQuestions.length) {

            showQuestion();

        }

        // QUIZ FINISHED
        else {

            localStorage.setItem(
                "score",
                String(score)
            );

            localStorage.setItem(
                "totalQuestions",
                String(quizQuestions.length)
            );


            const playerName =
                localStorage.getItem("playerName") || "Player";

            const category =
                localStorage.getItem("category") || "General";


            // SAVE RESULT TO MONGODB
            try {

                const response = await fetch(
                    "http://localhost:5000/api/results",
                    {
                        method: "POST",

                        headers: {
                            "Content-Type": "application/json"
                        },

                        body: JSON.stringify({
                            playerName: playerName,
                            category: category,
                            score: score,
                            totalQuestions: quizQuestions.length
                        })
                    }
                );


                if (!response.ok) {
                    throw new Error(
                        "Could not save result"
                    );
                }


                const result = await response.json();

                console.log(result);

                console.log(
                    "Quiz result saved successfully"
                );

            } catch (error) {

                console.error(
                    "Error saving quiz result:",
                    error
                );
            }


            // GO TO RESULT PAGE
            window.location.href = "result.html";
        }
    });
}


// RESULTS PAGE
const finalScore = document.getElementById("finalScore");

if (finalScore) {

    const name =
        localStorage.getItem("playerName") || "Player";

    const scoreValue =
        Number(localStorage.getItem("score")) || 0;

    const total =
        Number(localStorage.getItem("totalQuestions")) || 0;


    const percentage =
        total > 0
            ? Math.round((scoreValue / total) * 100)
            : 0;


    finalScore.textContent =
        scoreValue + " / " + total;


    document.getElementById("percentage").textContent =
        percentage + "%";


    document.getElementById("resultHeading").textContent =
        percentage >= 80
            ? "Excellent, " + name + "! 🎉"
            : percentage >= 50
                ? "Good Job, " + name + "! 👏"
                : "Keep Practising, " + name + "! 💪";


    document.getElementById("resultMessage").textContent =
        "You completed the quiz. Keep learning and improving!";
}