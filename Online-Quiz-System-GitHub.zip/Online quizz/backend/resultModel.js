const mongoose = require("mongoose");

const resultSchema = new mongoose.Schema({
    playerName: {
        type: String,
        required: true
    },

    category: {
        type: String,
        required: true
    },

    score: {
        type: Number,
        required: true
    },

    totalQuestions: {
        type: Number,
        required: true
    },

    percentage: {
        type: Number,
        required: true
    },

    date: {
        type: Date,
        default: Date.now
    }
});