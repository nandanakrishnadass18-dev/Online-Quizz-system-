const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB connection
mongoose.connect("mongodb://127.0.0.1:27017/quizapp")
    .then(() => {
        console.log("MongoDB connected successfully");
    })
    .catch((error) => {
        console.log("MongoDB connection error:", error);
    });

// Test route
app.get("/", (req, res) => {
    res.send("Quiz App Backend is Running");
});

// Get all questions
app.get("/api/questions", async (req, res) => {
    try {
        const questions = await mongoose.connection.db
            .collection("questions")
            .find({})
            .toArray();

        res.json(questions);
    } catch (error) {
        console.log(error);
        res.status(500).json({
            message: "Error getting questions"
        });
    }
});

// Save quiz result
app.post("/api/results", async (req, res) => {
    try {
        const result = req.body;

        await mongoose.connection.db
            .collection("results")
            .insertOne(result);

        res.json({
            message: "Result saved successfully"
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            message: "Error saving result"
        });
    }
});

// Get leaderboard
app.get("/api/leaderboard", async (req, res) => {
    try {
        const results = await mongoose.connection.db
            .collection("results")
            .find({})
            .sort({ score: -1 })
            .toArray();

        res.json(results);
    } catch (error) {
        console.log(error);
        res.status(500).json({
            message: "Error getting leaderboard"
        });
    }
});

// Start server
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});