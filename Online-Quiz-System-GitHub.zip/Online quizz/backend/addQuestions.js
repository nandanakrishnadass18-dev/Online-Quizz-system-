const mongoose = require("mongoose");

const questions = [
    // COMPUTER
    {
        category: "Computer",
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Text Machine Language",
            "Hyperlinks Text Mark Language",
            "Home Tool Markup Language"
        ],
        answer: "Hyper Text Markup Language"
    },
    {
        category: "Computer",
        question: "Which tag is used to create a paragraph?",
        options: ["<p>", "<h1>", "<br>", "<div>"],
        answer: "<p>"
    },
    {
        category: "Computer",
        question: "Which tag is used to insert an image?",
        options: ["<image>", "<img>", "<pic>", "<src>"],
        answer: "<img>"
    },
    {
        category: "Computer",
        question: "Which tag is used to create a hyperlink?",
        options: ["<link>", "<a>", "<href>", "<url>"],
        answer: "<a>"
    },
    {
        category: "Computer",
        question: "Which tag is used for the largest heading?",
        options: ["<h6>", "<head>", "<h1>", "<heading>"],
        answer: "<h1>"
    },

    // GENERAL Knowledge
    {
        category: "General knowledge",
        question: "What is the capital of India?",
        options: ["Mumbai", "New Delhi", "Chennai", "Kolkata"],
        answer: "New Delhi"
    },
    {
        category: "General knowledge",
        question: "Which is the largest ocean in the world?",
        options: ["Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"],
        answer: "Pacific Ocean"
    },
    {
        category: "General knowledge",
        question: "Who is known as the Father of the Indian Constitution?",
        options: [
            "Mahatma Gandhi",
            "Jawaharlal Nehru",
            "Dr. B. R. Ambedkar",
            "Sardar Patel"
        ],
        answer: "Dr. B. R. Ambedkar"
    },
    {
        category: "General knowledge",
        question: "Which planet is known as the Red Planet?",
        options: ["Earth", "Mars", "Jupiter", "Venus"],
        answer: "Mars"
    },
    {
        category: "General knowledge",
        question: "How many continents are there in the world?",
        options: ["5", "6", "7", "8"],
        answer: "7"
    },
    
    // SPORTS
    {
        category: "Sports",
        question: "How many players are there in a cricket team?",
        options: ["9", "10", "11", "12"],
        answer: "11"
    },
    {
        category: "Sports",
        question: "Which country hosted the 2016 Summer Olympics?",
        options: ["China", "Brazil", "Japan", "UK"],
        answer: "Brazil"
    },
    {
        category: "Sports",
        question: "How many rings are there in the Olympic symbol?",
        options: ["4", "5", "6", "7"],
        answer: "5"
    },
    {
        category: "Sports",
        question: "Which sport uses a shuttlecock?",
        options: ["Tennis", "Badminton", "Football", "Hockey"],
        answer: "Badminton"
    },
    {
        category: "Sports",
        question: "How many players are on the field for one soccer team?",
        options: ["9", "10", "11", "12"],
        answer: "11"
    },

    // SCIENCE
    {
        category: "Science",
        question: "What is the chemical formula of water?",
        options: ["CO2", "H2O", "O2", "NaCl"],
        answer: "H2O"
    },
    {
        category: "Science",
        question: "Which planet is closest to the Sun?",
        options: ["Earth", "Venus", "Mercury", "Mars"],
        answer: "Mercury"
    },
    {
        category: "Science",
        question: "What gas do humans need to breathe?",
        options: ["Carbon dioxide", "Oxygen", "Nitrogen", "Hydrogen"],
        answer: "Oxygen"
    },
    {
        category: "Science",
        question: "What is the largest organ in the human body?",
        options: ["Heart", "Brain", "Skin", "Liver"],
        answer: "Skin"
    },
    {
        category: "Science",
        question: "What force pulls objects toward the Earth?",
        options: ["Friction", "Gravity", "Magnetism", "Pressure"],
        answer: "Gravity"
    }
];

// Connect to MongoDB and insert questions
mongoose.connect("mongodb://127.0.0.1:27017/quizapp")
    .then(async () => {
        console.log("MongoDB connected");

        const db = mongoose.connection.db;

        await db.collection("questions").deleteMany({});

        await db.collection("questions").insertMany(questions);

        console.log("Questions inserted successfully");
        console.log("Total questions:", questions.length);

        await mongoose.connection.close();
        console.log("MongoDB connection closed");
    })
    .catch((error) => {
        console.log("Error:", error);
    });