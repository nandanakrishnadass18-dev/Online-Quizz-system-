const questions = [
    // HTML
    {
        category: "HTML",
        question: "What does HTML stand for?",
        options: [
            "Hyper Text Markup Language",
            "High Text Machine Language",
            "Hyperlinks Text Mark Language",
            "Home Tool Markup Language"
        ],
        answer: "Hyper Text Markup Language"
    },
    {
        category: "HTML",
        question: "Which tag is used to create a paragraph?",
        options: ["<p>", "<h1>", "<br>", "<div>"],
        answer: "<p>"
    },
    {
        category: "HTML",
        question: "Which tag is used to insert an image?",
        options: ["<image>", "<img>", "<pic>", "<src>"],
        answer: "<img>"
    },
    {
        category: "HTML",
        question: "Which tag is used to create a hyperlink?",
        options: ["<link>", "<a>", "<href>", "<url>"],
        answer: "<a>"
    },
    {
        category: "HTML",
        question: "Which tag is used for the largest heading?",
        options: ["<h6>", "<head>", "<h1>", "<heading>"],
        answer: "<h1>"
    },

    // GENERAL
    {
        category: "General",
        question: "What is the capital of India?",
        options: ["Mumbai", "New Delhi", "Chennai", "Kolkata"],
        answer: "New Delhi"
    },
    {
        category: "General",
        question: "Which is the largest ocean in the world?",
        options: ["Atlantic Ocean", "Indian Ocean", "Pacific Ocean", "Arctic Ocean"],
        answer: "Pacific Ocean"
    },
    {
        category: "General",
        question: "Who is known as the Father of the Indian Constitution?",
        options: [
            "Mahatma Gandhi",
            "Jawaharlal Nehru",
            "Dr. B. R. Ambedkar",
            "Sardar Patel"
        ],
        answer: "Dr. B. R. Ambedkar"
    },
    {
        category: "General",
        question: "Which planet is known as the Red Planet?",
        options: ["Earth", "Mars", "Jupiter", "Venus"],
        answer: "Mars"
    },
    {
        category: "General",
        question: "How many continents are there in the world?",
        options: ["5", "6", "7", "8"],
        answer: "7"
    },
    {
        category: "General",
        question: "Which country is known as the Land of the Rising Sun?",
        options: ["China", "Japan", "Thailand", "South Korea"],
        answer: "Japan"
    },
    {
        category: "General",
        question: "What is the national flower of India?",
        options: ["Rose", "Sunflower", "Lotus", "Jasmine"],
        answer: "Lotus"
    },
    {
        category: "General",
        question: "What is the currency of Japan?",
        options: ["Dollar", "Yen", "Won", "Euro"],
        answer: "Yen"
    },
    {
        category: "General",
        question: "Who wrote the play Hamlet?",
        options: [
            "Charles Dickens",
            "William Shakespeare",
            "Jane Austen",
            "Mark Twain"
        ],
        answer: "William Shakespeare"
    },
    {
        category: "General",
        question: "Which is the smallest continent by land area?",
        options: ["Europe", "Antarctica", "Australia", "South America"],
        answer: "Australia"
    },

    // SPORTS
    {
        category: "Sports",
        question: "How many players are there in a cricket team?",
        options: ["9", "10", "11", "12"],
        answer: "11"
    },
    {
        category: "Sports",
        question: "Which country hosted the 2016 Summer Olympics?",
        options: ["China", "Brazil", "Japan", "UK"],
        answer: "Brazil"
    },
    {
        category: "Sports",
        question: "How many rings are there in the Olympic symbol?",
        options: ["4", "5", "6", "7"],
        answer: "5"
    },
    {
        category: "Sports",
        question: "Which sport uses a shuttlecock?",
        options: ["Tennis", "Badminton", "Football", "Hockey"],
        answer: "Badminton"
    },
    {
        category: "Sports",
        question: "How many players are on the field for one soccer team?",
        options: ["9", "10", "11", "12"],
        answer: "11"
    },

    // SCIENCE
    {
        category: "Science",
        question: "What is the chemical formula of water?",
        options: ["CO2", "H2O", "O2", "NaCl"],
        answer: "H2O"
    },
    {
        category: "Science",
        question: "Which planet is closest to the Sun?",
        options: ["Earth", "Venus", "Mercury", "Mars"],
        answer: "Mercury"
    },
    {
        category: "Science",
        question: "What gas do humans need to breathe?",
        options: ["Carbon dioxide", "Oxygen", "Nitrogen", "Hydrogen"],
        answer: "Oxygen"
    },
    {
        category: "Science",
        question: "What is the largest organ in the human body?",
        options: ["Heart", "Brain", "Skin", "Liver"],
        answer: "Skin"
    },
    {
        category: "Science",
        question: "What force pulls objects toward the Earth?",
        options: ["Friction", "Gravity", "Magnetism", "Pressure"],
        answer: "Gravity"
    }
];